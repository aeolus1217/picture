
function init() {
  document.getElementById("donate").addEventListener("click", donate);
}

function donate() {
  window.open("https://p.ecpay.com.tw/C276E55", "_blank")
}

init();
